<script setup>
import { ref,
        onBeforeUpdate,onUpdated,
        watch
        } from 'vue'
const msg = ref('');
const count = ref(0);
let v1 = 0;
//1.Updating Phase: 
//ลงทะเบียน callback ก่อนที่ child element ของ component update
onBeforeUpdate(() => {
   console.log('1.onBeforeUpdate: '+ count.value);
   count.value++;
})

watch(count, (newVal, oldVal) => {
   console.log('2.watch:', oldVal, '->', newVal)
})

//2ลงทะเบียน callback หลัง child element ของ component update
onUpdated(() => {
   console.log('3.Updated: '+count.value);
}) 

</script>

<template>
  <div
    style="border: 2px solid blue;
          background-color: #fff9c4;
          padding: 10px;
          border-radius: 8px;">

    <!-- count UI varible -->
    <input v-model="msg" />    
    <h3>count : {{count}}</h3>     
    <h3>v1 : {{v1}}</h3>     
  </div>
</template>
