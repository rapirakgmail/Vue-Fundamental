<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'

console.log('0.set up')  
/*
Url design:  "/users"
             "/users?kname=Al"
             "/users?kname=J"
*/
const users = [
  { id: 1, name: 'John' },
  { id: 2, name: 'Jane' },
  { id: 3, name: 'Alex' }
]

const route = useRoute()
const keyword = ref(route.query.kname || '')

const router = useRouter()
function applyFilter() {
  console.log('12.applyFilter:keyword.value:'+keyword.value)  
  router.push({
    name: 'userList',
    query: {
      kname: keyword.value || undefined
    }
  })
  
}

///users
//users?kname=j
function getFilteredUsers() {
  const kw = route.query.kname

  console.log('11.getFilteredUsers:route.query.kname:'+route.query.kname)  
    
  if (!kw) {
    return users
  }

  return users.filter(u =>
    u.name.toLowerCase().includes(
      kw.toLowerCase()
    )
  )
}

const filteredUsers = getFilteredUsers()

onMounted(() => {
  console.log('1.Component Mounted')  
})

onUnmounted(() => {
  console.log('2.Component Unmounted')

})

</script>

<template>
 
  <div>
    <h3>User Filter</h3>

    <input
      v-model="keyword"
      placeholder="search name"
    />

    <button @click="applyFilter">
      Apply
    </button>
    <br>
    <br>
      Keyword : {{keyword}}
    <br>
  
    
    <RouterLink
      :to="{
        name: 'userList',
        query: {
          kname: keyword || undefined
        }
      }"
    >
      <button>link-Apply</button>
    </RouterLink>

    <hr />

    <ul>
      <li
        v-for="u in getFilteredUsers()"
        :key="u.id"
      >
        {{ u.name }}
      </li>
    </ul>
  </div>
</template>
