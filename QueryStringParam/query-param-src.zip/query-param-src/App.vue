<template>
  <h1>My Application</h1>
  <p>{{ $route.fullPath }}</p>
  
   <hr>
    <RouterView />
  <hr>

  <small>Copyright 2026</small>
</template>