import App from './App.vue'
import { createApp } from 'vue'
import { createRouter, createWebHashHistory } from 'vue-router'
import UserList from './UserList.vue'

const routerTable = createRouter({
  history: createWebHashHistory(),
  routes : [
            {
              path: '/',
              redirect:'/users'
            },
            {
              path: '/users',
              name: 'userList',
              component: UserList
            }
          ]
})

createApp(App)
   .use(routerTable)
  .mount('#app')