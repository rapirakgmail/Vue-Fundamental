<script setup></script>

<template>
  <div class="box">
    This is a dashed yellow box
    <slot></slot>
  </div>
</template>

<style>
.box {
  margin: 3px;
  border: 2px dashed #facc15;
  background-color: #fef9c3;
  padding: 20px;
  border-radius: 10px;
  width: fit-content;
}
</style>
