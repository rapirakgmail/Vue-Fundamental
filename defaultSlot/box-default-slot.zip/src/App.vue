<script setup>
import { ref } from 'vue'
import Box from './box.vue'

 
</script>

<template>
  <box> </box>
  <box> Line 1 </box>
  <box> 
    <h3 style="color: red;">line 1</h3> 
  </box>
 <box> 
    <h2 style="color: red;">line 1</h2> 
    <h1 style="color: yellowgreen;">line 1</h1> 
  </box>
</template>


