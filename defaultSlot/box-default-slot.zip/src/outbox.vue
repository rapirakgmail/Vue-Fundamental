<script setup>
 const msg = "Hello from Child"
 const count = 10 
</script>

<template>
   <div class="box">
        This is a dashed green box
   <slot :mytext="msg" :mcount="count"></slot>
 </div>
</template>

<style>
.box {
   display: block;
   border: 2px dashed #facc15;
   background: green;
   padding: 10px;
}
</style>



