<script setup>
import { ref, onBeforeMount,onMounted, 
              onBeforeUnmount,onUnmounted } from 'vue'
const msg = ref('');
const show = ref(false)

console.log('0.setup');

//1.Mounting Phase: 
//ลงทะเบียน callback ก่อนที่ vdom insert ไปยัง brower DOM 
onBeforeMount(  () => {
   console.log('1.onBeforeMount');
   //show.value = true
} );

//2.ลงทะเบียน callback หลังที่ vdom insert ไปยัง brower DOM
onMounted(() => {
   console.log('2.Mounted'); 
   //const box = document.getElementById('mybox')
   //box.style.backgroundColor = 'red'
})

//3.Unmounting Phase: 
//ลงทะเบียน callback ก่อน vdom remove จาก brower DOM
onBeforeUnmount(() => {
   console.log('3.onBeforeUnmount');   
})

//4.ลงทะเบียน callback หลัง vdom remove จาก brower DOM
onUnmounted(() => {
   console.log('4.onUnmounted');
})


</script>

<template>
  <div id="mybox"
    style="border: 2px solid blue;
          background-color: green;
          padding: 10px;
          border-radius: 8px;">
    <input v-if="show" v-model="msg" />
  </div>
</template>
