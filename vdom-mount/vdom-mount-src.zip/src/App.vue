<script setup>
  import Child from './Child.vue'
  import { ref } from 'vue'
  const showflag = ref(false)
</script>

<template>
  <Child v-if="showflag"></Child>
  <button @click="showflag = !showflag"> show/notshow</button>
 </template>
