<script setup>
import { ref, onBeforeMount,onMounted, 
              onBeforeUpdate,onUpdated,
              onBeforeUnmount,onUnmounted } from 'vue'
const msg = ref('');
const count = ref(0);

console.log('0.setup');

//1.Mounting Phase: 
//ลงทะเบียน callback ก่อนที่ dom insert
onBeforeMount(  () => {
   console.log('1.onBeforeMount');
} );
//ลงทะเบียน callback หลังที่ dom insert
onMounted(() => {
  console.log('2.Mounted'); 
})

//3.Updating Phase: 
//ลงทะเบียน callback ก่อนที่ child element ของ component update
onBeforeUpdate(() => {
   console.log('3.onBeforeUpdate: '+ count.value);
})

//ลงทะเบียน callback หลัง child element ของ component update
onUpdated(() => {
   console.log('4.Updated: '+count.value);
   count.value++;
}) 

//4.Unmounting Phase: 
//ลงทะเบียน callback ก่อน component unmount
onBeforeUnmount(() => {
   console.log('5.onBeforeUnmount');   
})

//ลงทะเบียน callback หลัง component unmount
onUnmounted(() => {
   console.log('6.onUnmounted');
})


</script>

<template>
  <div
    style="border: 2px solid blue;
          background-color: #fff9c4;
          padding: 10px;
          border-radius: 8px;">
    <input v-model="msg" />    
    
  </div>
</template>
