
<script setup>
  import Child from './Child.vue'
  const str_var = 'Hello'
  const num_var = 125
  const obj_var = { id:123456789, name:'vue' }
</script>

<template>
  <Child
    sc_param = "1a1"  
    :sparam   ="str_var"
    :nparam   ="123"
    :oparam   ="obj_var"
  />
</template>