<script setup>
import { ref } from 'vue'

const props = defineProps({
  sc_param: String,
  sparam: String,
  nparam: Number,
  oparam: Object
})

const myInt = ref(props.nparam)
myInt.value = myInt.value * 100
</script>

<template>
  <div>
    {{ 'sc_param = ' + (props.sc_param + '-abc') }}
    <br>
    {{ 'sparam = ' + sparam }}
    <br>
    {{ 'nparam = ' + (props.nparam + 7777) }}
    <br>
    {{ 'oparam.id = ' + props.oparam.id }}
    <br>
    {{ 'oparam.name = ' + props.oparam.name }}
    <br>
    {{ 'myInt = ' + myInt }}

  </div>
</template>

