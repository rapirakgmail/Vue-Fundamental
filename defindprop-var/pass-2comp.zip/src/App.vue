<script setup>
import { ref } from 'vue'
import Child from './Child.vue'

const _count = ref('0')
let   _vcount = 0;
function onClickCount()
{
  _count.value = 'a'+_count.value;
}

function onClickVCount()
{
  _vcount++;
}

</script>

<template>
  <h2>Parent count: {{ _count }}</h2>
  <Child { :count="_count", :vcount="_vcount" }  />
  <button v-on:click="onClickCount"> count++</button>

  <button v-on:click="onClickVCount"> vcount++</button>

  <h2>Parent vcount: {{ _vcount }}</h2>
</template>