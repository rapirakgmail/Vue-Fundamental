<script setup>
import {ref} from "vue"
const props = defineProps({
  count: String ,
  vcount: Number
})
const val = ref(0);
function change() {
  //props.vcount++;
  
  val.value++;
}

</script>

<template>
  <div style="border-style: dashed;padding: 10px;">
    <p>Child count: {{ count }}</p>
    <p>Child vcount: {{ vcount }}</p>
    <button @click="change">Change</button>

    <p>Child val: {{ val }}</p>
  </div>
</template>

