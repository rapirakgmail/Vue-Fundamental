<script setup>
import { ref, reactive } from 'vue'

const id_var = ref(123)

const obj_var = reactive({
  id: 1123,
  name: 'vue'
})

function updateRef() {
  id_var.value = id_var.value + 1
}

function updateReactive() {
  obj_var.id = obj_var.id + 1
  obj_var.name = 'vue updated'+1
}
</script>

<template>
  <div>
    <h3>REF</h3>
    <p>ID: {{ id_var }}</p>
    <button @click="updateRef">
      Update Ref
    </button>

    <hr>

    <h3>REACTIVE</h3>
    <p>ID: {{ obj_var.id }}</p>
    <p>Name: {{ obj_var.name }}</p>
    <button @click="updateReactive">
      Update Reactive
    </button>
  </div>
</template>
