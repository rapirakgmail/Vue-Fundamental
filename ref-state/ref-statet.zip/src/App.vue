<script setup>
import { ref, watch, reactive } from "vue";

// state variable
const var1 = ref(0);

//normal variable
let var2 = 0;
// actions
function incVar1() {
  var1.value++;
}

function incVar2() {
  var2++;
  console.log("var2:", var2);
}

// watch
watch(var1, (newValue, oldValue) => {
  console.log("var1 changed:", oldValue, "→", newValue);
});
</script>

<template>
  <div>
    <p>var1 = {{ var1 }}</p>
    <button @click="incVar1()">var1++</button>

    <p>var2 = {{ var2 }}</p>
    <button @click="incVar2()">var2++</button>
  </div>
</template>
