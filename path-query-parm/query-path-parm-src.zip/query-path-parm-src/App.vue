<template>
  <h1>My Application</h1>
  <p>{{ $route.path }}</p>
  <p>{{ $route.fullPath }}</p>

   <hr>
    <RouterView />
  <hr>

  <small>Copyright 2026</small>
</template>