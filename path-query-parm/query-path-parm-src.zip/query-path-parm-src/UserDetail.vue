
<script setup>
import { useRoute } from 'vue-router'
  const route = useRoute()
</script>

<template>
  <h2>User Detail</h2>
  
  <p v-if="route.query.mode === 'view'">
    Mode : VIEW
  </p>

  <p v-else>
    Mode : EDIT
  </p>

  <p>ID : {{ route.params.id }}</p>
  <p>Name : {{ route.params.name }}</p>
 
 <RouterLink
  :to="{ name: 'user-list'}" > Back </RouterLink>

</template>
