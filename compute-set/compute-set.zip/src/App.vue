<script setup>
import { ref, computed } from 'vue'

const message = ref('')
const upperText = computed({
  get() {
    console.log(`1.get: message.value = ${message.value}`)
    return message.value
  },
  set(value) {
    console.log(`2.set: value = ${value}`)
    message.value = value.toUpperCase()
  }
})

 // upperText.value = '1.abcd'; 
</script>

<template>

  <input v-model="upperText" />

<!--  <p>{{ upperText }}</p>  -->

</template>