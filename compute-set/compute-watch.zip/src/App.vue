<script setup>
import { ref, watch } from 'vue'

const message = ref('')

watch(message, (newValue) => {
  console.log('1.before:'+newValue);
  message.value = newValue.toUpperCase()
  console.log('2.after:'+message.value);
})

</script>

<template>
  
  <input v-model="message" />


</template>