<!-- App.vue -->
<template>
  <header style="background-color:lightyellow; padding:10px;">
    <h1>Hello App!</h1>
    <p>  <strong>Current route path:</strong> {{ $route.fullPath }} </p>
  </header>
    <nav class="menu">
      <RouterLink to="/">Home</RouterLink>
      <RouterLink to="/about">About</RouterLink>
      <RouterLink to="/optionview">Optionview</RouterLink>
    </nav>
    
    <main style="background-color:lightblue; padding:10px;">
      <RouterView />
    </main>

    <footer style="background-color:lightgreen; padding:10px;">
      Footer
   </footer>
</template>

<style>
.menu {
  width: 100%;
  border: 2px solid black;
  padding: 10px;
  display: flex;
  gap: 10px;
}

.menu a {
  color: blue;
  border: 1px solid gray;
  padding: 8px;
  text-decoration: none;
}
.menu a.router-link-active {
  background: lightgray;
}
</style>
