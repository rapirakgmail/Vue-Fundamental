<script setup>
import { ref } from 'vue'
import Child from './Child.vue'

const userName = ref('John')

function updateName() {
  userName.value = 'Happy'
}
</script>

<template>
  <h3>Prop Binding</h3>

  <Child :name="userName" />

  <button @click="updateName">
    Change Name
  </button>
</template>