<script setup>
import { ref } from 'vue'

const textColor = ref('red')
const fontSize = ref('24px')

function updateStyle() {
  textColor.value = 'green'
  fontSize.value = '60px'
}
</script>

<template>
  <h3>Style Binding</h3>
  <!-- Static Binding -->
  <div style="color: blue; font-size: 24px;">
    Static Style
  </div>
  <br>
  <!-- Dynamic Binding -->
  <div :style="{ color: textColor, fontSize: fontSize }">
    Dynamic Style
  </div>
  <br>

  <button @click="updateStyle">
    Change Style
  </button>
</template>