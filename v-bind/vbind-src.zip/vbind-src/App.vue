<script setup>
import AttributeDemo from './AttributeDemo.vue'
import StyleDemo from './StyleDemo.vue'
import ClassDemo from './ClassDemo.vue'
import ParentDemo from './ParentDemo.vue'
</script>

<template>
  <AttributeDemo />
  <hr>
  <StyleDemo />
  <hr>
  <ClassDemo />
  <hr>
  <ParentDemo />
</template>
