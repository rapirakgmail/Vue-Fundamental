<script setup>
import { ref } from 'vue'
const imageUrl = ref('https://www.gstatic.com/webp/gallery3/2.png')
function updateimage() {
  imageUrl.value =
    'https://www.gstatic.com/webp/gallery3/3.png'
}
</script>

<template>
  <h3>Attribute Binding</h3>

  <!-- static -->
  <img
    src="https://www.gstatic.com/webp/gallery3/2.png"
    width="100px"
  >

  <!--  dynamic -->
  <img
    :src="imageUrl"
    width="100px"
  >

  <br><br>

  <button @click="updateimage">
    Change Image
  </button>
</template>
