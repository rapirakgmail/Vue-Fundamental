<script setup>
import { ref } from 'vue'

const isActive = ref(true)

function updateClass() {
  isActive.value = !isActive.value;
}
</script>

<template>
  <h3>Class Binding</h3>

  <!-- Static Class -->
  <div class="myclass">
    Static Class
  </div>

  <br>

  <!-- Dynamic Class -->
  <div :class="{ myclass: isActive }">
    Dynamic Class
  </div>

  <br>

  <button @click="updateClass">
    Add/Remove Class
  </button>
</template>

<style>
.myclass {
  color: blue;
  font-weight: bold;
}
</style>