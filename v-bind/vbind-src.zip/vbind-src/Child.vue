<script setup>
defineProps({
  name: String
})
</script>

<template>
  <div>
    User : {{ name }}
  </div>
</template>