<template>
  <h2>User List</h2>

  <div
    style="
      display: flex;
      align-items: center;
      gap: 10px;
      margin-bottom: 10px;
    "
  >
    <div style="width: 100px;">John</div>

    <RouterLink
      :to="{
        name: 'user-detail',
        params: {
          id: 1,
          name: 'John',
          mode: 'edit'
        }
      }"
    >
      <button style="width: 80px;">Edit</button>
    </RouterLink>

    <RouterLink
      :to="{
        name: 'user-detail',
        params: {
          id: 1,
          name: 'John',
          mode: 'view'
        }
      }"
    >
      <button style="width: 80px;">View</button>
    </RouterLink>
  </div>

  <div
    style="
      display: flex;
      align-items: center;
      gap: 10px;
    "
  >
    <div style="width: 100px;">Mary</div>

    <RouterLink
      :to="{
        name: 'user-detail',
        params: {
          id: 2,
          name: 'Mary',
          mode: 'edit'
        }
      }"
    >
      <button style="width: 80px;">Edit</button>
    </RouterLink>

    <RouterLink
      :to="{
        name: 'user-detail',
        params: {
          id: 2,
          name: 'Mary',
          mode: 'view'
        }
      }"
    >
      <button style="width: 80px;">View</button>
    </RouterLink>
  </div>
</template>