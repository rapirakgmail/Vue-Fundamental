import { createApp } from 'vue'
import { createRouter, createWebHashHistory } from 'vue-router'

import App from './App.vue'
import UserDetail from './UserDetail.vue'
import UserList from './UserList.vue'


const router = createRouter({
  history: createWebHashHistory(),
  routes: [
    {
      path: '/',
      name: 'user-list',
      component: UserList
    },
    {
      path: '/detail/:id/:name/:mode',
      name: 'user-detail',
      component: UserDetail
    }
  ]
})

createApp(App)
  .use(router)
  .mount('#app')