<script setup>
import { ref } from 'vue'

// primitive (เก็บข้อมูลจริง)
let numbers = [10, 20, 30, 40, 50]

// state (เอาไว้แสดงผล)
const average = ref(0)

function calculateAverage() {
  let sum = 0
   for (let i = 0; i < numbers.length; i++) {
    sum += numbers[i]
  }
  average.value = sum / numbers.length
}
</script>

<template>
  <div>
    <button @click="calculateAverage"> Calculate Average </button>
    <p>  Average: {{ average }} </p>
  </div>
</template>

