<script setup>
import { ref } from 'vue'

// state variable
let msg1 =ref('hello-1')
let msg2 ='hello-2'

</script>

<template>
  {{msg1}}
  <input v-model="msg1" />
  <br></br>
  {{msg2}}
  <input v-model="msg2" />
 
 </template>
