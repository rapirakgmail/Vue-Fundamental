<script setup>
import { ref, computed } from 'vue'

const item1 = ref(0)
const item2 = ref(0)
const total = computed({
  get() {
      console.log(`item1 = ${item1.value}, item2 = ${item2.value}`);
     return item1.value + item2.value;
  }
})

</script>

<template>
  <div>
    <div>
      รายการที่ 1 :
      <input v-model.number="item1" type="number" />
    </div>
    <div>
      รายการที่ 2 :
      <input v-model.number="item2" type="number" />
    </div>
    <hr />
    
  </div>
</template>