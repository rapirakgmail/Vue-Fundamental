<script setup>
import { ref, computed } from 'vue'
const item1 = ref(0)
const item2 = ref(0)
</script>

<template>
  <div>
    <div>
      รายการที่ 1 :
      <input v-model.number="item1" type="number" />
    </div>
    <div>
      รายการที่ 2 :
      <input v-model.number="item2" type="number" />
    </div>
    <hr />
    <p>รวมราคา : {{ item1+item1 }}</p>
    <p>VAT 7% : {{ ((item1+item1)*0.07).toFixed(2) }}</p>
    <p>ราคาสุทธิ : {{ (item1+item1)*0.07+(item1+item1) }}</p>
  </div>
</template>