import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export const useAppStore = defineStore('app', () => {

  const count = ref(0)
  const username = ref('guest')

  // computed
  const doubleCount = computed(() => {
    return count.value * 2
  })

  function increment() {
    count.value++
  }

  function setUsername(name) {
    username.value = name
  }

  return {
    count,
    username,
    doubleCount,
    increment,
    setUsername
  }
})
