
import { createApp } from 'vue'
import { createPinia } from 'pinia' //import lib
import App from './App.vue'


const app = createApp(App)
const pinia = createPinia()   //binding 
app.use(pinia)         

app.mount('#app')

