<script setup>
import { useAppStore } from './appStore'
const store = useAppStore()
</script>

<template>
  <h2>Component B </h2>
  <input
    v-model="store.username"
    placeholder="enter username"
  />

  <p>Count: {{ store.count }}</p>
</template>
