<script setup>
import ComponentA  from './CompA.vue'
import ComponentB  from './CompB.vue'
import ComponentC  from './CompC.vue'
</script>

<template>
  <ComponentA />
  <hr />
  <ComponentB />
  <hr />
  <ComponentC />
</template>

