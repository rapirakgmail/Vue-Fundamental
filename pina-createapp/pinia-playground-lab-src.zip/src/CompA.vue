<script setup>
import { useAppStore } from './appStore'

const store = useAppStore()

</script>

<template>
  <h2>Component A </h2>

  <button @click="store.increment()">+ count</button>
  <p>User: {{ store.username }}</p>

</template>
