<script setup>
import { useAppStore } from './appStore'
const store = useAppStore()
</script>

<template>
  <h2>Component C (View) </h2>
  <p>Count (var): {{ store.count }}</p>
  <p>doubleCount (computed) : {{ store.doubleCount }}</p>
  <p>Name (var) : {{ store.username }}</p>

</template>
