
<script setup>
import {
  ref,
  onMounted,
  onUnmounted
  
} from 'vue'

const search = ref('')


onMounted(() => {
  console.log('AboutView mounted')
})

onUnmounted(() => {
  console.log('AboutView unmounted')
})


</script>


<template>
  <h2>AboutView</h2>
  <label>
    Search: <input v-model.trim="search" maxlength="20">
  </label>
</template>