<script setup>
import { useRouter } from 'vue-router'

import {
  ref,
  onMounted,
  onUnmounted
} from 'vue'


const router = useRouter()
function goToAbout() {
  //router.push('/optionview')
  router.push({name:'voption'})
}

onMounted(() => {
  console.log('HomeView mounted')
})

onUnmounted(() => {
  console.log('HomeView unmounted')
})


</script>

<template>
  <h2>HomeView</h2>

  <button @click="goToAbout">
    Go to About
  </button>
</template>
