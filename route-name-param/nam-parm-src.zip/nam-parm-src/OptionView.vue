<script setup>
import {
  ref,
  onMounted,
  onUnmounted
} from 'vue'


const search = ref('')

onMounted(() => {
  console.log('OptionView mounted')
})

onUnmounted(() => {
  console.log('OptionView unmounted')
})


</script>

<template>
  <h2>Option View</h2>
  
   <p>Select a Technology Brand:</p>
    <div>
        <input type="radio" 
               id="Netflix" 
               name="brand" 
               value="Netflix">
        <label for="Netflix">Netflix</label>
    </div>

    <div>
        <input type="radio" 
               id="Audi" 
               name="brand" 
               value="Audi">
        <label for="Audi">Audi</label>
    </div>

    <div>
        <input type="radio" 
               id="Microsoft" 
               name="brand" 
               value="Microsoft" checked>
        <label for="Microsoft">Microsoft</label>
    </div>
    
</template>