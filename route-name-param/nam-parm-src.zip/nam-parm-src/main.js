import { createApp } from 'vue'
import App from './App.vue'

import HomeView from './HomeView.vue'
import AboutView from './AboutView.vue'
import OptionView from './OptionView.vue'
import { createMemoryHistory, createRouter,
          createWebHashHistory ,createWebHistory} from 'vue-router'

//create mapping url and component routing table 
const  routerObj = createRouter({
                            history: createWebHashHistory(), 
                                  //createWebHistory() or createWebHashHistory() in production
                            routes:  [
                                          //{ path: '/', redirect: '/about' },
                                          { path: '/about', component: AboutView },
                                          { path: '/', component: HomeView },
                                          { path: '/myoptionview', component: OptionView,name:'voption' },
                                        ]
                          });

const app = createApp(App)
app
.use(routerObj)  //before  mount('#app')
.mount('#app')

