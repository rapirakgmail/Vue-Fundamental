import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export const useAppStoreA = defineStore('counterA', () => {
  const countA = ref(0)
  function incrementA() {
    countA.value++
  }
  return {
    countA,
    incrementA,
  }
})

export const useAppStoreB = defineStore('counterA', () => {
  const countB = ref(0) 
  function incrementB() {
    countB.value++
  }
  return {
    countB,
    incrementB,
  }
})

