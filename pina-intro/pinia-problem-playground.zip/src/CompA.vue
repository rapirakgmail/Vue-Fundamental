<script setup>
import { useAppStoreA,useAppStoreB } from './appStore'

const storeA = useAppStoreA()
const storeB  = useAppStoreB()


function DoSomeThingAB() {

  if(storeA === storeB)
   {
    console.log( '1.DoSomeThingAB -> storeA === storeB ' );
    console.log( storeA.$id );  //ชื่อของ "storge"
    console.log( storeB.$id );
  } 

  storeA.incrementA();
  console.log( '2.storeA.countA = %d',storeA.countA );
  console.log( '3.storeB.countA = %d',storeB.countA );
  console.log(  '4.storeB.countB = %d',storeB.countB );
  console.log( '5.storeA.countB = %d',storeA.countB );
  storeB.countB = 0;
  storeB.countB = storeB.countB+storeA.countA;
  console.log( 'ุ6.storeA.countB = %d',storeA.countB );
  console.log( '7.storeB.countB = %d',storeB.countB );
  storeB.incrementA();
  console.log( 'ุ8.storeA.countB = %d',storeA.countA );
  console.log( '9.storeB.countB = %d',storeB.countA );
  storeB.incrementB();
}

</script>

<template>
  <h2>Component A </h2>
  <button @click="DoSomeThingAB()"> DoSomeThingAB </button>
 
</template>
