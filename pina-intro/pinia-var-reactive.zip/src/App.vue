<script setup>
import ComponentA  from './CompA.vue'
</script>

<template>
  <ComponentA />
</template>

