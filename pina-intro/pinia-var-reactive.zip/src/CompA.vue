<script setup>
import { appStore } from './appStore'
import { ref } from 'vue'

const storeA1 = appStore();
const storeA2 = appStore();

const var1  = ref(0);
const var2  = ref(0);

function doSomethingPiniaVar() {
  if(storeA1 === storeA2) {
      console.log( "1.storeA1.$id = %s", storeA1.$id );  //ชื่อของ "storge"
      console.log( "2.storeA2.$id = %s", storeA2.$id );  //ชื่อของ "storge"
  }
  console.log( "3.storeA1.count = %d", storeA1.count );  //ชื่อของ "storge"
  console.log( "4.storeA2.count = %s", storeA2.count );  //ชื่อของ "storge"
  
  storeA1.increment();

  console.log( "5.storeA1.count = %d", storeA1.count );  //ชื่อของ "storge"
  console.log( "6.storeA2.count = %s", storeA2.count );  //ชื่อของ "storge"

}

function doSomethingVar() {

  if(var1 === var2) {
      console.log(`1.var1 = ${var1}`);
      console.log(`2.var2 = ${var2.value}`);
  } 
  if(var1.value === var2.value) {
      console.log(`1.var1.value = '${var1.value}'`);
      console.log(`2.var2.value = '${var2.value}'`);
  } 

  var1.value++;
  console.log( "5.var1.value = %d", var1.value );  //ชื่อของ "storge"
  console.log( "6.var2.value = %d", var2.value );  //ชื่อของ "storge"

}

</script>

<template>
  <h2>Component A </h2>
  <button @click="doSomethingVar()"> doSomethingVar </button>
  <br>
  <button @click="doSomethingPiniaVar()"> doSomethingPiniaVar </button>
 
</template>
