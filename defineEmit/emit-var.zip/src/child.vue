<script setup>
import { defineEmits } from 'vue'

//return emit function
const emit = defineEmits(['f1','f2'])
let count = 0;

// ส่งข้อมูลออกไป
function sendDataF1() {
  count = count +1;
  emit('f1', "my text-"+count)
}

function sendDataF2() {
  emit('f2', count+1,count+2 )
}

</script>

<template>
  <button @click="sendDataF1">sendDataF1</button>
  <br></br>
  <button @click="sendDataF2">sendDataF2</button>
</template>




