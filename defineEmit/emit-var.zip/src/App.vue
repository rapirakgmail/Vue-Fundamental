<script setup>
  import Child from './child.vue'
  import {ref} from 'vue'
  const f1_msg = ref("")
  const f2_msg = ref("")

  
  function f1_sub(parm1) {
    f1_msg.value = parm1;
  }
  
  function f2_sub(parm1,parm2) {
    f2_msg.value = parm1+'-'+parm2;
  }

</script>


<template>
  <h1> f1-msg : {{f1_msg}} </h1> 
  <h1> f2-msg : {{f2_msg}} </h1> 
  <Child 
     @f1="f1_sub"
     @f2="f2_sub" 
  /> 
</template>

