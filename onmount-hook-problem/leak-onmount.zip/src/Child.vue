<script setup>
import {ref, onMounted, onUnmounted } from 'vue'
let timer = null;

let socket;
const count = ref(0);
onMounted(() => {
  console.log('1. onMounted ' )
  //การ hook routine timer ให้ run ทุก 1 วินาที
  timer = setInterval( () => {
    console.log('running...', count.value)
    count.value++;
  }, 1000)

})

/* off
onUnmounted(() => {
  console.log('2. onUnmounted ' )
  //การยกเลิก การ routine timer 
  clearInterval(timer)
})
*/
</script>

<template>
  <div
    style="border: 2px solid blue;
          background-color: #fff9c4;
          padding: 10px;
          border-radius: 8px;">
    <h5>{{count}}</h5>
  </div>
</template>

