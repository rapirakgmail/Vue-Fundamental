<script setup>
  import Child from './Child.vue'
  import { ref } from 'vue'

  const msg = ref('input:')
  const showflag = ref(false)
</script>

<template>
  <Child v-if="showflag"></Child>
  <input  v-model="msg" />
  <br></br>
  <button @click="showflag = !showflag"> show/notshow</button>
 </template>
