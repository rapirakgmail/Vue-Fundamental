<script setup>
import { ref, onBeforeMount,onMounted, 
              onBeforeUpdate,onUpdated,
              onBeforeUnmount,onUnmounted } from 'vue'
const msg = ref('');
const count = ref(0);

//3.Updating Phase: 
//ลงทะเบียน callback ก่อนที่ child element ของ component update
onBeforeUpdate(() => {
   console.log('3.onBeforeUpdate: '+ count.value);
})

//ลงทะเบียน callback หลัง child element ของ component update
onUpdated(() => {
   console.log('4.Updated: '+count.value);
   count.value++;
}) 

</script>

<template>
  <div
    style="border: 2px solid blue;
          background-color: #fff9c4;
          padding: 10px;
          border-radius: 8px;">

    <!-- count UI varible -->
    <input v-model="msg" />    
    <h3> {{count}}</h3>     
  </div>
</template>
